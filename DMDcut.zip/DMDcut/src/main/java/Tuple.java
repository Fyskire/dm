// just because java sucks
class Tuple {

    int x, y;

    Tuple (int x, int y){

        this.x = x;
        this.y = y;
    }
}