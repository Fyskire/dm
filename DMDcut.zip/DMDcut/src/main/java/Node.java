import java.util.ArrayList;

public class Node {
	
	boolean checked = false;
	ArrayList<WeightedEdge> connect = null;
	float density;

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
